from django.apps import AppConfig


class Foody1Config(AppConfig):
    name = 'foody_1'
